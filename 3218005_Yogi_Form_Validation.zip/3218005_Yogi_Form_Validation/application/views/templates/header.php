<!DOCTYPE html>
<html>
<head>
	<title>SKRIPSI</title>
</head>
<body>
	<h1 align="center">SKRIPSI</h1>
