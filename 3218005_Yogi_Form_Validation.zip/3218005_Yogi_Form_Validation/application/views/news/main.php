<h2><?php echo $title; ?></h2>   
<table align="center">
	<tr>
		<td>
		<?php echo anchor(site_url('news/create'), "Insert Data"); ?>	
		</td>
	</tr>
	<tr>
		<td>
			<?php echo anchor(site_url('news/view'), "Tampil Data"); ?>
		</td>
	</tr>


</table>