<?php echo form_open('news/login'); ?>  
	<form action="" method="POST">
		<table align="center">
			<tr>
				<td>USERNAME</td>
				<td><input type="text" name="username"></td>
			</tr>
			<tr>
				<td>PASSWORD</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="LOGIN"></td>
			</tr>
			
		</table>
	</form>
</body>
</html>